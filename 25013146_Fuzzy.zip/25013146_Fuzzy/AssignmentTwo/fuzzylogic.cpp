#include <algorithm>
#include "fuzzylogic.h"

// Helper function for emergency override
float emergency_override(float inputs[], fuzzy_system_rec fz) {
    float angle_input = inputs[INPUT_X];

    // CRITICAL EMERGENCY: > 15 in fuzzy units
    if (fabs(angle_input) > 20.0) {
        return (angle_input > 0) ? fz.output_values[out_nvl] * 1.2 : fz.output_values[out_pvl] * 1.2;
    }

    // SEVERE CRISIS: > 10 in fuzzy units
    if (fabs(angle_input) > 15.0) {  // Increased from 10.0
        float base_force = (angle_input > 0) ? fz.output_values[out_nl] : fz.output_values[out_pl];
        return base_force * 2.0;  // Increased from 1.8
    }

    // MODERATE CRISIS: > 7 in fuzzy units
    if (fabs(angle_input) > 10.0) {  // Increased from 7.0
        float base_force = (angle_input > 0) ? fz.output_values[out_nm] : fz.output_values[out_pm];
        return base_force * 1.6;  // Increased from 1.4
    }

    return 0.0; // No override
}

void initFuzzyRules(fuzzy_system_rec *fl) {
    int rule_idx = 0;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_nl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_nl;
    fl->rules[rule_idx].out_fuzzy_set = out_pvl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_nl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ns;
    fl->rules[rule_idx].out_fuzzy_set = out_pvl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_nl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ze;
    fl->rules[rule_idx].out_fuzzy_set = out_pvl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_nl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ps;
    fl->rules[rule_idx].out_fuzzy_set = out_pl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_nl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_pl;
    fl->rules[rule_idx].out_fuzzy_set = out_pm;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ns;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_nl;
    fl->rules[rule_idx].out_fuzzy_set = out_pl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ns;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ns;
    fl->rules[rule_idx].out_fuzzy_set = out_pl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ns;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ze;
    fl->rules[rule_idx].out_fuzzy_set = out_pl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ns;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ps;
    fl->rules[rule_idx].out_fuzzy_set = out_pm;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ns;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_pl;
    fl->rules[rule_idx].out_fuzzy_set = out_ps;
    rule_idx++;


    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ze;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_nl;
    fl->rules[rule_idx].out_fuzzy_set = out_pl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ze;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ns;
    fl->rules[rule_idx].out_fuzzy_set = out_pm;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ze;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ze;
    fl->rules[rule_idx].out_fuzzy_set = out_ze;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ze;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ps;
    fl->rules[rule_idx].out_fuzzy_set = out_nm;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ze;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_pl;
    fl->rules[rule_idx].out_fuzzy_set = out_nl;
    rule_idx++;


    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ps;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_nl;
    fl->rules[rule_idx].out_fuzzy_set = out_ns;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ps;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ns;
    fl->rules[rule_idx].out_fuzzy_set = out_nm;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ps;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ze;
    fl->rules[rule_idx].out_fuzzy_set = out_nl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ps;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ps;
    fl->rules[rule_idx].out_fuzzy_set = out_nvl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_ps;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_pl;
    fl->rules[rule_idx].out_fuzzy_set = out_nvl;
    rule_idx++;


    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_pl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_nl;
    fl->rules[rule_idx].out_fuzzy_set = out_nm;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_pl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ns;
    fl->rules[rule_idx].out_fuzzy_set = out_nl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_pl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ze;
    fl->rules[rule_idx].out_fuzzy_set = out_nvl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_pl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_ps;
    fl->rules[rule_idx].out_fuzzy_set = out_nvl;
    rule_idx++;

    fl->rules[rule_idx].inp_index[0] = INPUT_X;
    fl->rules[rule_idx].inp_fuzzy_set[0] = in_pl;
    fl->rules[rule_idx].inp_index[1] = INPUT_Y;
    fl->rules[rule_idx].inp_fuzzy_set[1] = in_pl;
    fl->rules[rule_idx].out_fuzzy_set = out_nvl;
    rule_idx++;
}

void initMembershipFunctions(fuzzy_system_rec *fl) {
    // Input X fuzzy sets
    fl->inp_mem_fns[INPUT_X][in_nl] = init_trapz(-100.0, -5.0, -100.0, -5.0, left_trapezoid);
    fl->inp_mem_fns[INPUT_X][in_ns] = init_trapz(-7.0, -3.5, -1.5, -0.4, regular_trapezoid);
    fl->inp_mem_fns[INPUT_X][in_ze] = init_trapz(-2.0, -0.5, 0.5, 2.0, regular_trapezoid);
    fl->inp_mem_fns[INPUT_X][in_ps] = init_trapz(0.4, 1.5, 3.5, 7.0, regular_trapezoid);
    fl->inp_mem_fns[INPUT_X][in_pl] = init_trapz(5.0, 100.0, 5.0, 100.0, right_trapezoid);

    // Input Y fuzzy sets
    fl->inp_mem_fns[INPUT_Y][in_nl] = init_trapz(-50.0, -5.0, -50.0, -5.0, left_trapezoid);
    fl->inp_mem_fns[INPUT_Y][in_ns] = init_trapz(-6.0, -4.0, -0.05, 0.0, regular_trapezoid);
    fl->inp_mem_fns[INPUT_Y][in_ze] = init_trapz(-3.0, -0.001, 0.001, 3.0, regular_trapezoid);
    fl->inp_mem_fns[INPUT_Y][in_ps] = init_trapz(0.0, 0.05, 4.0, 6.0, regular_trapezoid);
    fl->inp_mem_fns[INPUT_Y][in_pl] = init_trapz(5.0, 50.0, 5.0, 50.0, right_trapezoid);
}

void initFuzzySystem(fuzzy_system_rec *fl) {
    fl->no_of_inputs = 2;
    fl->no_of_rules = 25;
    fl->no_of_inp_regions = 5;
    fl->no_of_outputs = 9;


    coefficient_A = 35.0;
    coefficient_B = 4.0;
    coefficient_C = 0.1;
    coefficient_D = 0.1;


    fl->output_values[out_nvl] = -190;
    fl->output_values[out_nl] = -145;
    fl->output_values[out_nm] = -75;
    fl->output_values[out_ns] = -38;
    fl->output_values[out_ze] = 0;
    fl->output_values[out_ps] = 38;
    fl->output_values[out_pm] = 75;
    fl->output_values[out_pl] = 145;
    fl->output_values[out_pvl] = 190;

    fl->rules = (rule*)malloc(fl->no_of_rules * sizeof(rule));
    fl->allocated = true;
    initFuzzyRules(fl);
    initMembershipFunctions(fl);
}

float fuzzy_system(float inputs[], fuzzy_system_rec fz) {
    // Check for emergency override FIRST
    float emergency_force = emergency_override(inputs, fz);
    if (fabs(emergency_force) > 100.0) {
        // Emergency takes precedence
        return emergency_force;
    }

    // Normal fuzzy logic
    int i, j;
    short variable_index, fuzzy_set;
    float sum1 = 0.0, sum2 = 0.0, weight;
    float m_values[MAX_NO_OF_INPUTS];

    for (i = 0; i < fz.no_of_rules; i++) {
        for (j = 0; j < fz.no_of_inputs; j++) {
            variable_index = fz.rules[i].inp_index[j];
            fuzzy_set = fz.rules[i].inp_fuzzy_set[j];
            m_values[j] = trapz(inputs[variable_index], fz.inp_mem_fns[variable_index][fuzzy_set]);
        }

        // Apply rule boosting
        weight = min_of(m_values, fz.no_of_inputs);

        // Boost emergency rules
        if (fz.rules[i].inp_fuzzy_set[0] == in_nl || fz.rules[i].inp_fuzzy_set[0] == in_pl) {
            weight = weight * 2.0;  // 200% boost
        }

        sum1 += weight * fz.output_values[fz.rules[i].out_fuzzy_set];
        sum2 += weight;
    }

    if (fabs(sum2) < TOO_SMALL) {
        cout << "\r\nFLPRCS Error: Sum2 in fuzzy_system is 0." << endl;
        return emergency_force;  // Return emergency force if normal logic fails
    }

    float normal_force = (sum1 / sum2);

    // Combine with emergency force if any
    if (fabs(emergency_force) > 0) {
        float blend_factor = 0.7;  // 70% emergency, 30% normal
        return blend_factor * emergency_force + (1.0 - blend_factor) * normal_force;
    }

    return normal_force;
}

trapezoid init_trapz(float x1, float x2, float x3, float x4, trapz_type typ) {
    trapezoid trz;
    trz.a = x1;
    trz.b = x2;
    trz.c = x3;
    trz.d = x4;
    trz.tp = typ;

    switch (trz.tp) {
        case regular_trapezoid:
            trz.l_slope = 1.0 / (trz.b - trz.a);
            trz.r_slope = 1.0 / (trz.c - trz.d);
            break;
        case left_trapezoid:
            trz.r_slope = 1.0 / (trz.a - trz.b);
            trz.l_slope = 0.0;
            break;
        case right_trapezoid:
            trz.l_slope = 1.0 / (trz.b - trz.a);
            trz.r_slope = 0.0;
            break;
    }
    return trz;
}

float trapz(float x, trapezoid trz) {
    switch (trz.tp) {
        case left_trapezoid:
            if (x <= trz.a) return 1.0;
            if (x >= trz.b) return 0.0;
            return trz.r_slope * (x - trz.b);

        case right_trapezoid:
            if (x <= trz.a) return 0.0;
            if (x >= trz.b) return 1.0;
            return trz.l_slope * (x - trz.a);

        case regular_trapezoid:
            if ((x <= trz.a) || (x >= trz.d)) return 0.0;
            if ((x >= trz.b) && (x <= trz.c)) return 1.0;
            if ((x >= trz.a) && (x <= trz.b)) return trz.l_slope * (x - trz.a);
            if ((x >= trz.c) && (x <= trz.d)) return trz.r_slope * (x - trz.d);
    }
    return 0.0;
}

float min_of(float values[], int no_of_inps) {
    float val = values[0];
    for (int i = 1; i < no_of_inps; i++) {
        if (values[i] < val) val = values[i];
    }
    return val;
}

void free_fuzzy_rules(fuzzy_system_rec *fz) {
    if (fz->allocated) {
        free(fz->rules);
    }
    fz->allocated = false;
}