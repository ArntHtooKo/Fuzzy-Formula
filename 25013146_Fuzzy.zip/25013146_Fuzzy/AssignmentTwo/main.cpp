///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    ARTIFICIAL INTELLIGENCE 159302
//    INVERTED PENDULUM SIMULATION
//
//	  Description: Inverted pendulum simulation with fuzzy logic engine and animation functions
//
//    Run Parameters:
//
//    Keys for Operation:
//
//	  History:  dates of revision
//              Aug 2024
//              Sept 2022
//
//    Start-up code by:  Dr. Napoleon Reyes, n.h.reyes@massey.ac.nz
//    					 Computer Science, INMS
//						 Massey University-Albany
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

// #include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <iostream>
#include <fstream>
#include <deque>
#include <set>
#include <vector>
#include <chrono>
#include <sstream>


#include "sprites.h"
#include "transform.h"
#include "fuzzylogic.h"


#if defined __unix__ || defined __APPLE__

    #include <graphics.h>

#elif defined __WIN32__

    #include <windows.h>
    #include "graphics.h"

#endif


using namespace std;


/// Global Variables ///////////////////////////////////////////////////////////////////////


bool DEBUG_MODE=false;
float WORLD_MAXX, WORLD_MAXY;
int fieldX1, fieldY1, fieldX2, fieldY2; //playing field boundaries
BoundaryType worldBoundary,deviceBoundary;
char keyPressed[5];
fuzzy_system_rec g_fuzzy_system;
float coefficient_A, coefficient_B, coefficient_C, coefficient_D;



struct WorldStateType{

	void init(){
		x=0.0;
		x_dot=0.0;
		x_double_dot = 0.0;
		angle = 0.0;
		angle_dot = 0.0;
		angle_double_dot = 0.0;
		F = 0.0;
	}

	float x;
	float x_dot;
	float x_double_dot;
	float angle;
	float angle_dot;
	float angle_double_dot;

	float const mb=0.1;
	float const g=9.8;
	float const m=1.1;
	float const l=0.5;

	float F;
};


struct DataSetType{
   vector<float> x;
   vector<float> y;
   vector<vector<float> > z;
};

DataSetType dataSet;

int NUM_OF_DATA_POINTS;

// Function Prototypes ////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////
float getKey() {

	  float F=0.0;

#if defined __WIN32__

     if(GetAsyncKeyState(VK_LEFT) < 0) {
        //"LEFT ARROW";
		  F=-15.0;
	  }

	  if(GetAsyncKeyState(VK_RIGHT) < 0) {
        F=15.0;

        //"RIGHT ARROW"
	  }

#endif

	  return F;
}

////////////////////////////////////////////////////////////////////////////////



void initPendulumWorld(){

   //widescreen
   fieldX1 = getmaxx() / 10;
   fieldX2 = getmaxx() - (getmaxx() / 10);
   fieldY1 = getmaxy() / 9;
   fieldY2 = getmaxy() - (getmaxy() / 9);


    worldBoundary.x1 = -2.4;
    //worldBoundary.y1 = 1.2;
	worldBoundary.y1 = 3;
    worldBoundary.x2 = 2.4;
    worldBoundary.y2 = -0.4;

    deviceBoundary.x1 = fieldX1;
    deviceBoundary.y1 = fieldY1;
    deviceBoundary.x2 = fieldX2;
    deviceBoundary.y2 = fieldY2;

    WORLD_MAXX=worldBoundary.x2-worldBoundary.x1;
    WORLD_MAXY=worldBoundary.y2-worldBoundary.y1;

}

void drawInvertedPendulumWorld(){

	setcolor(WHITE);
	rectangle(xDev(worldBoundary,deviceBoundary,worldBoundary.x1),yDev(worldBoundary,deviceBoundary,worldBoundary.y1),
	          xDev(worldBoundary,deviceBoundary,worldBoundary.x2),yDev(worldBoundary,deviceBoundary,worldBoundary.y2));

	settextstyle(SMALL_FONT, HORIZ_DIR, 7);
	settextjustify(CENTER_TEXT, CENTER_TEXT);

	setcolor(WHITE);

	outtextxy((deviceBoundary.x1 + deviceBoundary.x2)/2, deviceBoundary.y1 - 3 * textheight("H"),"ARTIFICIAL INTELLIGENCE 159302");

    settextstyle(SMALL_FONT, HORIZ_DIR, 7);
	outtextxy((deviceBoundary.x1 + deviceBoundary.x2)/2, deviceBoundary.y1 - 2 * textheight("H"),"INVERTED PENDULUM");

	settextstyle(SMALL_FONT, HORIZ_DIR, 7);
	outtextxy((deviceBoundary.x1 + deviceBoundary.x2)/2, deviceBoundary.y1 - textheight("H"),"FUZZY LOGIC CONTROLLER");
	settextstyle(SMALL_FONT, HORIZ_DIR, 5);
	outtextxy((deviceBoundary.x2 - textwidth("START-UP CODE by:  n.h.reyes@massey.ac.nz")), deviceBoundary.y2 + textheight("H"),"START-UP CODE by:  n.h.reyes@massey.ac.nz  (C) Massey University");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// BEGIN - DYNAMICS OF THE SYSTEM
float calc_angular_acceleration( const WorldStateType& s){
	float a_double_dot=0.0;
	float numerator=0.0;
	float denominator=0.0;

	numerator = (s.m * s.g * sin(s.angle) - (cos(s.angle) * (s.F + ((s.mb) * s.l * s.angle_dot * s.angle_dot * sin(s.angle) ) ) )  );
	denominator = (  ((4/3)*s.m * s.l) - (s.mb * s.l * cos(s.angle) * cos(s.angle)));
	if(numerator == 0.0 || denominator == 0.0){
	   a_double_dot=0.0;
	} else {
	   a_double_dot = numerator/denominator;
    }

	return a_double_dot;
}

float calc_horizontal_acceleration( const WorldStateType& s){
	float x_double_dot=0.0;
	float numerator=0.0;


	numerator = ( s.F + s.mb * s.l * (s.angle_dot * s.angle_dot)* sin(s.angle) - s.angle_double_dot * cos(s.angle)   );
	if(numerator == 0.0){
        x_double_dot=0.0;
	} else {
	    x_double_dot = numerator / s.m;
    }
	return x_double_dot;
}
// END - DYNAMICS OF THE SYSTEM
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void welcomeScreen(){
	drawInvertedPendulumWorld();


	settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    setcolor(YELLOW);
    settextjustify(LEFT_TEXT, CENTER_TEXT);

    string msg = "Getting started...";
	outtextxy((deviceBoundary.x1 + textwidth("N")), deviceBoundary.y1 + (8*textheight("H")),(char *)msg.c_str());
	setcolor(GREEN);
    msg = "Please click mouse on Command prompt";
	outtextxy((deviceBoundary.x1 + textwidth("N")), deviceBoundary.y1 + (10*textheight("H")),(char *)msg.c_str());
	msg = "window, then type the initial angle.";
	outtextxy((deviceBoundary.x1 + textwidth("N")), deviceBoundary.y1 + (11*textheight("H")),(char *)msg.c_str());
}

void displayInfo(const WorldStateType& s, const string msg="", const string timeElapsed=""){
	setcolor(WHITE);
	// outtextxy((deviceBoundary.x1 + deviceBoundary.x2)/2, deviceBoundary.y1 - 2 * textheight("H"),"INVERTED PENDULUM");
	// settextstyle(TRIPLEX_FONT, HORIZ_DIR, 1);
	// outtextxy((deviceBoundary.x1 + deviceBoundary.x2)/2, deviceBoundary.y1 - textheight("H"),"FUZZY LOGIC CONTROLLER");
	settextstyle(SMALL_FONT, HORIZ_DIR, 6);

	char angleStr[120];
	char xStr[120];

	float a=((s.angle*180/3.14));

	if(a > 360){
		a = a / 360.0;
	}

	sprintf(xStr,"x = %4.2f",s.x);
	outtextxy((deviceBoundary.x2 - textwidth("n.h.reyes")), deviceBoundary.y1 + (5*textheight("H")),const_cast<char*>(xStr));

	sprintf(angleStr,"angle = %4.2f",a);
	outtextxy((deviceBoundary.x2 - textwidth("n.h.reyes")), deviceBoundary.y1 + (6*textheight("H")),const_cast<char*>(angleStr));

	sprintf(angleStr,"F = %4.2f",s.F);
	outtextxy((deviceBoundary.x2 - textwidth("n.h.reyes")), deviceBoundary.y1 + (7*textheight("H")),const_cast<char*>(angleStr));

    if(!msg.empty()){
    	settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    	setcolor(GREEN);
    	settextjustify(LEFT_TEXT, CENTER_TEXT);
	    outtextxy((deviceBoundary.x1 + textwidth("TIME")), deviceBoundary.y1 + (3*textheight("H")),const_cast<char*>(msg.c_str()));
    }

    if(!timeElapsed.empty()){
    	settextstyle(DEFAULT_FONT, HORIZ_DIR, 3);
    	setcolor(WHITE);
    	settextjustify(LEFT_TEXT, CENTER_TEXT);
	    outtextxy((deviceBoundary.x1 + textwidth("TIME")), deviceBoundary.y1 + (5*textheight("H")),(char *)timeElapsed.c_str());
    }

}
void runInvertedPendulum() {
    using namespace std::chrono;

    WorldStateType previousState, updatedState;
    initPendulumWorld();

    static bool displayPageToggle;
    float controlInputValues[2];
    const float timeDelta = 0.002;
    float externalControlForce = 0.0;

    previousState.init();
    updatedState.init();

    welcomeScreen();

    Cart cartComponent(1.0, worldBoundary.y2 + 0.125);
    Rod rodComponent(1.0, worldBoundary.y2 + 0.125 + 0.35);

    initFuzzySystem(&g_fuzzy_system);

    system_clock::time_point simulationStartTime;
    std::string statusMessageText;
    int frameUpdateInterval = 2;
    float userAngleInput = 0;
    bool exitRequested = false;

    int startupForceBoostCounter = 0;
    bool balanceAchievedLogged = false;

    while (!exitRequested) {
        previousState.init();
        previousState.x = 0.0;

        std::cout << "Provide initial tilt value [-60, 60] (empty to quit): ";
        userAngleInput = -90;

        std::string inputBuffer;
        std::getline(std::cin, inputBuffer);
        if (!inputBuffer.empty()) {
            std::istringstream inputConverter(inputBuffer);
            inputConverter >> userAngleInput;
        }

        if ((userAngleInput < -60) || (userAngleInput > 60)) {
            exitRequested = true;
        }

        if (userAngleInput == 0.0) {
            userAngleInput = 0.1 * (3.14 / 180);
        } else {
            userAngleInput = userAngleInput * (3.14 / 180);
        }

        previousState.angle = userAngleInput;

        float initialAngleDegrees = fabs(userAngleInput * 180.0 / 3.14);
        balanceAchievedLogged = false;

        if (initialAngleDegrees >= 35.0) {
            startupForceBoostCounter = 320;
            std::cout << "CRITICAL: Initial angle (" << initialAngleDegrees << "°). Applying maximum stabilization protocol!" << std::endl;
            std::cout << "Warning: Operating at extreme system boundaries!" << std::endl;
        } else if (initialAngleDegrees >= 33.0) {
            startupForceBoostCounter = 300;
            std::cout << "CRITICAL: Initial angle (" << initialAngleDegrees << "°). Applying maximum stabilization protocol!" << std::endl;
        } else if (initialAngleDegrees >= 32.0) {
            startupForceBoostCounter = 280;
            std::cout << "CRITICAL: Initial angle (" << initialAngleDegrees << "°). Applying maximum stabilization protocol!" << std::endl;
        } else if (initialAngleDegrees >= 31.0) {
            startupForceBoostCounter = 270;
            std::cout << "CRITICAL: Starting angle (" << initialAngleDegrees << "°). Enhanced corrective measures activated!" << std::endl;
        } else if (initialAngleDegrees >= 30.0) {
            startupForceBoostCounter = 250;
            std::cout << "CRITICAL: Starting angle (" << initialAngleDegrees << "°). Enhanced corrective measures activated!" << std::endl;
        } else if (initialAngleDegrees >= 28.0) {
            startupForceBoostCounter = 220;
            std::cout << "Warning: High starting angle (" << initialAngleDegrees << "°). Aggressive control mode engaged!" << std::endl;
        } else if (initialAngleDegrees >= 25.0) {
            startupForceBoostCounter = 180;
            std::cout << "Warning: High starting angle (" << initialAngleDegrees << "°). Aggressive control mode engaged!" << std::endl;
        } else if (initialAngleDegrees >= 20.0) {
            startupForceBoostCounter = 130;
            std::cout << "Warning: Significant starting angle (" << initialAngleDegrees << "°). Increased corrective action!" << std::endl;
        } else if (initialAngleDegrees >= 15.0) {
            startupForceBoostCounter = 60;
            std::cout << "Note: Moderate starting angle (" << initialAngleDegrees << "°). Standard corrective measures applied." << std::endl;
        } else {
            startupForceBoostCounter = 0;
        }

        int stabilityCheckCounter = 0;
        float previousAngleSnapshot = 0;
        float previousPositionSnapshot = 0;
        bool systemStabilized = false;

        simulationStartTime = system_clock::now();
        bool simulationComplete = false;

        float maximumObservedAngle = fabs(userAngleInput * 180.0 / 3.14);
        float maximumObservedVelocity = 0.0;
        float maximumObservedPosition = 0.0;
        int totalOperationCycles = 0;

#if defined __unix__ || defined __APPLE__
        SDL_Event systemEvent;
#endif

        while (!simulationComplete) {
#if defined __unix__ || defined __APPLE__
            while (SDL_PollEvent(&systemEvent)) {
                if (systemEvent.type == SDL_QUIT) {
                    simulationComplete = true;
                } else if (systemEvent.type == SDL_KEYDOWN) {
                    if (systemEvent.key.keysym.sym == SDLK_ESCAPE) {
                        simulationComplete = true;
                    }
                }
            }
#elif defined __WIN32__
            if (GetAsyncKeyState(VK_ESCAPE) < 0) {
                simulationComplete = true;
            }
#endif

            setactivepage(displayPageToggle);
            cleardevice();
            drawInvertedPendulumWorld();

            if (stabilityCheckCounter >= 2) {
                previousAngleSnapshot = previousState.angle;
                previousPositionSnapshot = previousState.x;
            }

            stabilityCheckCounter++;
            totalOperationCycles++;
            stabilityCheckCounter = stabilityCheckCounter % 200;

            float currentAngleDeg = fabs(previousState.angle * 180.0 / 3.14);
            if (currentAngleDeg > maximumObservedAngle) {
                maximumObservedAngle = currentAngleDeg;
            }
            if (fabs(previousState.angle_dot) > maximumObservedVelocity) {
                maximumObservedVelocity = fabs(previousState.angle_dot);
            }
            if (fabs(previousState.x) > maximumObservedPosition) {
                maximumObservedPosition = fabs(previousState.x);
            }

            if (stabilityCheckCounter == 199) {
                if (fabs(previousState.angle) <= 0.05 &&
                    (fabs(previousState.angle - previousAngleSnapshot) <= 0.03) &&
                    fabs(previousState.x) <= 0.02 &&
                    fabs(previousState.x - previousPositionSnapshot) <= 0.09) {
                    if (!balanceAchievedLogged) {
                        std::cout << "\nSystem balanced successfully!" << std::endl;
                        std::cout << "  Maximum angle during stabilization: " << maximumObservedAngle << "°" << std::endl;
                        std::cout << "  Maximum angular velocity: " << maximumObservedVelocity << " rad/s" << std::endl;
                        std::cout << "  Maximum position reached: " << maximumObservedPosition << "m" << std::endl;
                        std::cout << "  Total cycles to stabilize: " << totalOperationCycles << std::endl;
                        balanceAchievedLogged = true;
                    }
                    systemStabilized = true;
                    simulationComplete = true;
                }
            }

            controlInputValues[INPUT_X] = (coefficient_A * previousState.angle) + (coefficient_B * previousState.angle_dot);
            controlInputValues[INPUT_Y] = (coefficient_C * previousState.x) + (coefficient_D * previousState.x_dot);

            float currentAngleInDegrees = fabs(previousState.angle * 180.0 / 3.14);
            float maximumInputValue = 80.0f;
            float minimumInputValue = -80.0f;

            if (currentAngleInDegrees > 30.0) {
                maximumInputValue = 150.0f;
            } else if (currentAngleInDegrees > 25.0) {
                maximumInputValue = 120.0f;
            } else if (currentAngleInDegrees > 20.0) {
                maximumInputValue = 100.0f;
            } else if (currentAngleInDegrees > 15.0) {
                maximumInputValue = 85.0f;
            }

            if (controlInputValues[INPUT_X] > maximumInputValue) controlInputValues[INPUT_X] = maximumInputValue;
            if (controlInputValues[INPUT_X] < minimumInputValue) controlInputValues[INPUT_X] = minimumInputValue;

            float angularCorrectionForce = -fuzzy_system(controlInputValues, g_fuzzy_system);

            float safetyBoundaryMargin = 0.4;
            if (currentAngleInDegrees > 28.0) {
                safetyBoundaryMargin = 0.2;
            }

            float distanceFromEdge = 2.4 - fabs(previousState.x);
            float boundarySafetyFactor = (distanceFromEdge < safetyBoundaryMargin) ?
                (distanceFromEdge / safetyBoundaryMargin) : 1.0;

            if (currentAngleInDegrees > 28.0) {
                boundarySafetyFactor = pow(boundarySafetyFactor, 1.2);
            }

            static float previousEmergencyFactor = 0.0;
            float emergencyResponseFactor = 0.0;

            if (currentAngleInDegrees > 35.0) {
                emergencyResponseFactor = 1.7;
            } else if (currentAngleInDegrees > 33.0) {
                emergencyResponseFactor = 1.6;
            } else if (currentAngleInDegrees > 31.0) {
                emergencyResponseFactor = 1.45;
            } else if (currentAngleInDegrees > 30.0) {
                emergencyResponseFactor = 1.3;
            } else if (currentAngleInDegrees > 28.0) {
                emergencyResponseFactor = 1.1;
            } else if (currentAngleInDegrees > 25.0) {
                emergencyResponseFactor = 1.0;
            } else if (currentAngleInDegrees > 20.0) {
                emergencyResponseFactor = 0.8 + 0.2 * ((currentAngleInDegrees - 20.0) / 5.0);
            } else if (currentAngleInDegrees > 15.0) {
                emergencyResponseFactor = 0.4 + 0.4 * ((currentAngleInDegrees - 15.0) / 5.0);
            } else if (currentAngleInDegrees > 10.0) {
                emergencyResponseFactor = 0.1 + 0.3 * ((currentAngleInDegrees - 10.0) / 5.0);
            }

            emergencyResponseFactor = 0.8 * emergencyResponseFactor + 0.2 * previousEmergencyFactor;
            previousEmergencyFactor = emergencyResponseFactor;

            float desiredPosition = 0.0;
            float positionError = desiredPosition - previousState.x;
            float basePositionGain = 28.0f;
            float baseVelocityGain = 10.0f;

            float positionScalingFactor;
            if (currentAngleInDegrees > 35.0) {
                positionScalingFactor = 0.001;
            } else if (currentAngleInDegrees > 33.0) {
                positionScalingFactor = 0.002;
            } else if (currentAngleInDegrees > 31.0) {
                positionScalingFactor = 0.003;
            } else if (currentAngleInDegrees > 30.0) {
                positionScalingFactor = 0.008;
            } else if (currentAngleInDegrees > 28.0) {
                positionScalingFactor = 0.03;
            } else if (currentAngleInDegrees > 25.0) {
                positionScalingFactor = 0.12;
            } else if (currentAngleInDegrees > 20.0) {
                positionScalingFactor = 0.35;
            } else if (currentAngleInDegrees > 15.0) {
                positionScalingFactor = 0.65;
            } else {
                positionScalingFactor = 1.0;
            }

            float positionalCorrectionForce = 0.0;

            bool positionWarningZone = (fabs(previousState.x) > 1.6);
            bool positionDangerZone = (fabs(previousState.x) > 1.75);
            bool positionCriticalZone = (fabs(previousState.x) > 1.9);

            bool movingTowardBoundary = false;
            float boundaryVelocityThreshold = 0.4;
            if ((previousState.x < 0 && previousState.x_dot < -boundaryVelocityThreshold) ||
                (previousState.x > 0 && previousState.x_dot > boundaryVelocityThreshold)) {
                movingTowardBoundary = true;
            }

            if (positionCriticalZone && movingTowardBoundary) {
                float emergencyBoundaryForce = -70.0f * (previousState.x / fabs(previousState.x));
                emergencyBoundaryForce -= 25.0f * previousState.x_dot;
                positionalCorrectionForce = emergencyBoundaryForce;

                if ((previousState.x < 0 && angularCorrectionForce < 0) ||
                    (previousState.x > 0 && angularCorrectionForce > 0)) {
                    angularCorrectionForce *= 0.6;
                }
            } else if (positionDangerZone && movingTowardBoundary) {
                float dangerBoundaryForce = -50.0f * (previousState.x / fabs(previousState.x));
                dangerBoundaryForce -= 18.0f * previousState.x_dot;
                positionalCorrectionForce = dangerBoundaryForce;

                if ((previousState.x < 0 && angularCorrectionForce < 0) ||
                    (previousState.x > 0 && angularCorrectionForce > 0)) {
                    angularCorrectionForce *= 0.75;
                }
            } else if (positionWarningZone) {
                float warningBoundaryForce = -30.0f * (previousState.x / fabs(previousState.x));
                warningBoundaryForce -= 12.0f * previousState.x_dot;
                positionalCorrectionForce = warningBoundaryForce * 0.5;
            } else {
                if (fabs(angularCorrectionForce) > 50.0) {
                    if ((previousState.x < -1.4 && angularCorrectionForce < 0) ||
                        (previousState.x > 1.4 && angularCorrectionForce > 0)) {
                        positionalCorrectionForce = -0.18 * angularCorrectionForce * boundarySafetyFactor;
                    } else {
                        positionalCorrectionForce = -(basePositionGain * positionError +
                                                     baseVelocityGain * previousState.x_dot) *
                                                   boundarySafetyFactor * positionScalingFactor;
                    }
                } else {
                    positionalCorrectionForce = -(basePositionGain * positionError +
                                                 baseVelocityGain * previousState.x_dot) *
                                               boundarySafetyFactor * positionScalingFactor;
                }
            }

            previousState.F = angularCorrectionForce + positionalCorrectionForce;

            if (startupForceBoostCounter > 0) {
                float boostMultiplier;

                if (initialAngleDegrees >= 35.0) {
                    boostMultiplier = 3.0;
                } else if (initialAngleDegrees >= 33.0) {
                    boostMultiplier = 2.75;
                } else if (initialAngleDegrees >= 32.0) {
                    boostMultiplier = 2.5;
                } else if (initialAngleDegrees >= 31.0) {
                    boostMultiplier = 2.35;
                } else if (initialAngleDegrees >= 30.0) {
                    boostMultiplier = 2.2;
                } else if (initialAngleDegrees >= 28.0) {
                    boostMultiplier = 1.9;
                } else if (initialAngleDegrees >= 25.0) {
                    boostMultiplier = 1.7;
                } else if (initialAngleDegrees >= 20.0) {
                    boostMultiplier = 1.5;
                } else if (initialAngleDegrees >= 15.0) {
                    boostMultiplier = 1.25;
                } else {
                    boostMultiplier = 1.0;
                }

                float currentSpeed = fabs(previousState.x_dot);
                float velocityAdaptationFactor = 1.0;
                float maximumSafeVelocity = 4.5;

                if (initialAngleDegrees >= 35.0) {
                    if (currentSpeed > maximumSafeVelocity * 0.8) {
                        velocityAdaptationFactor = 0.85;
                        boostMultiplier *= velocityAdaptationFactor;
                    }
                } else {
                    if (currentSpeed > maximumSafeVelocity * 0.65) {
                        velocityAdaptationFactor = 1.0 - ((currentSpeed - maximumSafeVelocity * 0.65) /
                                                         (maximumSafeVelocity * 0.35));
                        velocityAdaptationFactor = fmax(velocityAdaptationFactor, 0.5);
                        boostMultiplier *= velocityAdaptationFactor;
                    }
                }

                float boostDecayFactor;
                if (initialAngleDegrees >= 28.0) {
                    boostDecayFactor = (float)startupForceBoostCounter / 250.0;
                } else {
                    boostDecayFactor = pow((float)startupForceBoostCounter / 150.0, 2.0);
                }

                boostMultiplier = 1.0 + (boostMultiplier - 1.0) * boostDecayFactor;

                if (initialAngleDegrees >= 35.0) {
                    previousState.F *= boostMultiplier;
                } else if (!positionCriticalZone || !movingTowardBoundary) {
                    previousState.F *= boostMultiplier;
                }

                startupForceBoostCounter--;

                if (startupForceBoostCounter > 280 && initialAngleDegrees >= 35.0) {
                    if (previousState.angle > 0 && previousState.F > 0) {
                        previousState.F = -fabs(previousState.F) * 1.7;
                    } else if (previousState.angle < 0 && previousState.F < 0) {
                        previousState.F = fabs(previousState.F) * 1.7;
                    }
                } else if (startupForceBoostCounter > 260 && initialAngleDegrees >= 33.0) {
                    if (previousState.angle > 0 && previousState.F > 0) {
                        previousState.F = -fabs(previousState.F) * 1.6;
                    } else if (previousState.angle < 0 && previousState.F < 0) {
                        previousState.F = fabs(previousState.F) * 1.6;
                    }
                } else if (startupForceBoostCounter > 240 && initialAngleDegrees >= 31.0) {
                    if (previousState.angle > 0 && previousState.F > 0) {
                        previousState.F = -fabs(previousState.F) * 1.5;
                    } else if (previousState.angle < 0 && previousState.F < 0) {
                        previousState.F = fabs(previousState.F) * 1.5;
                    }
                } else if (startupForceBoostCounter > 220 && initialAngleDegrees >= 28.0) {
                    if (previousState.angle > 0 && previousState.F > 0) {
                        previousState.F = -fabs(previousState.F) * 1.4;
                    } else if (previousState.angle < 0 && previousState.F < 0) {
                        previousState.F = fabs(previousState.F) * 1.4;
                    }
                }
            }

            float maximumAllowedForce = 75.0f;
            float minimumRequiredForce = 0.0f;

            if (fabs(previousState.x_dot) > 2.0) {
                maximumAllowedForce = 60.0f;
            } else if (emergencyResponseFactor > 0.9) {
                maximumAllowedForce = 170.0f;
            } else if (emergencyResponseFactor > 0.7) {
                maximumAllowedForce = 140.0f;
            } else if (startupForceBoostCounter > 0) {
                maximumAllowedForce = 100.0f;
            }

            if (currentAngleInDegrees > 35.0) {
                if (fabs(previousState.x_dot) < 1.5) {
                    maximumAllowedForce = 240.0f;
                } else if (fabs(previousState.x_dot) < 2.5) {
                    maximumAllowedForce = 190.0f;
                } else {
                    maximumAllowedForce = 130.0f;
                }
                minimumRequiredForce = 45.0f;
            } else if (currentAngleInDegrees > 33.0) {
                if (fabs(previousState.x_dot) < 1.4) {
                    maximumAllowedForce = 220.0f;
                } else if (fabs(previousState.x_dot) < 2.3) {
                    maximumAllowedForce = 175.0f;
                } else {
                    maximumAllowedForce = 120.0f;
                }
                minimumRequiredForce = 40.0f;
            } else if (currentAngleInDegrees > 31.0) {
                if (fabs(previousState.x_dot) < 1.3) {
                    maximumAllowedForce = 200.0f;
                } else if (fabs(previousState.x_dot) < 2.2) {
                    maximumAllowedForce = 160.0f;
                } else {
                    maximumAllowedForce = 105.0f;
                }
                minimumRequiredForce = 35.0f;
            } else if (currentAngleInDegrees > 30.0) {
                if (fabs(previousState.x_dot) < 1.3) {
                    maximumAllowedForce = 185.0f;
                } else if (fabs(previousState.x_dot) < 2.2) {
                    maximumAllowedForce = 145.0f;
                } else {
                    maximumAllowedForce = 95.0f;
                }
                minimumRequiredForce = 32.0f;
            } else if (currentAngleInDegrees > 28.0) {
                maximumAllowedForce = 155.0f;
                minimumRequiredForce = 27.0f;
            } else if (currentAngleInDegrees > 25.0) {
                maximumAllowedForce = 140.0f;
                minimumRequiredForce = 24.0f;
            } else if (currentAngleInDegrees > 20.0) {
                maximumAllowedForce = 120.0f;
                minimumRequiredForce = 20.0f;
            }

            if (fabs(previousState.x) > 1.6) {
                float edgeDistance = 2.4 - fabs(previousState.x);
                float boundaryScaleFactor = edgeDistance / 0.8;
                boundaryScaleFactor = fmax(boundaryScaleFactor, 0.4);
                maximumAllowedForce *= boundaryScaleFactor;
            }

            if (previousState.F > maximumAllowedForce) previousState.F = maximumAllowedForce;
            if (previousState.F < -maximumAllowedForce) previousState.F = -maximumAllowedForce;

            if (emergencyResponseFactor > 0.7 && fabs(previousState.F) < minimumRequiredForce) {
                float correctiveDirection = (previousState.angle > 0) ? -1.0 : 1.0;

                bool wouldPushToBoundary = false;
                if ((previousState.x < -1.95 && correctiveDirection < 0) ||
                    (previousState.x > 1.95 && correctiveDirection > 0)) {
                    wouldPushToBoundary = true;
                }

                if (!wouldPushToBoundary) {
                    float emergencyBoost = 1.0 + emergencyResponseFactor * 0.38;
                    previousState.F = minimumRequiredForce * correctiveDirection * emergencyBoost;
                }
            }

            float velocityBoostMultiplier = 1.0;
            float currentAngularSpeed = fabs(previousState.angle_dot);

            if (currentAngularSpeed > 2.9) {
                velocityBoostMultiplier = 1.28;
            } else if (currentAngularSpeed > 1.9) {
                velocityBoostMultiplier = 1.18;
            } else if (currentAngularSpeed > 1.3) {
                velocityBoostMultiplier = 1.1;
            }

            if (startupForceBoostCounter < 60 && fabs(previousState.x) < 1.6) {
                previousState.F *= velocityBoostMultiplier;
            }

            if (currentAngleInDegrees > 33.0 && !positionCriticalZone) {
                float progressiveScaling = 1.0 + (currentAngleInDegrees - 33.0) * 0.08;
                progressiveScaling = fmin(progressiveScaling, 1.8);
                previousState.F *= progressiveScaling;
            } else if (currentAngleInDegrees > 25.0 && !positionCriticalZone) {
                float progressiveScaling = 1.0 + (currentAngleInDegrees - 25.0) * 0.055;
                progressiveScaling = fmin(progressiveScaling, 1.55);
                previousState.F *= progressiveScaling;
            }

            externalControlForce = 0.0;

#if defined __unix__ || defined __APPLE__
            if (ismouseclick(WM_RBUTTONDOWN)) {
                externalControlForce = 15;
            } else if (ismouseclick(WM_LBUTTONDOWN)) {
                externalControlForce = -15;
            }
#elif defined __WIN32__
            externalControlForce = getKey();
#endif

            if (externalControlForce != 0.0) {
                previousState.F = externalControlForce;
                std::cout << "Manual override: Force = " << externalControlForce << "N" << std::endl;
            }

            if (DEBUG_MODE || (currentAngleInDegrees > 28.0 && totalOperationCycles % 50 == 0)) {
                std::cout << "Operation cycle: " << totalOperationCycles << std::endl;
                std::cout << "  Current angle: " << (previousState.angle * 180.0 / 3.14) << "°" << std::endl;
                std::cout << "  Angular velocity: " << previousState.angle_dot << " rad/s" << std::endl;
                std::cout << "  X position: " << previousState.x << "m" << std::endl;
                std::cout << "  X velocity: " << previousState.x_dot << "m/s" << std::endl;
                std::cout << "  Angular force component: " << angularCorrectionForce << "N" << std::endl;
                std::cout << "  Positional force component: " << positionalCorrectionForce << "N" << std::endl;
                std::cout << "  Total applied force: " << previousState.F << "N" << std::endl;
                std::cout << "  Warning zone active: " << positionWarningZone << std::endl;
                std::cout << "  Danger zone active: " << positionDangerZone << std::endl;
                std::cout << "  Critical zone active: " << positionCriticalZone << std::endl;
            }

            updatedState.angle_double_dot = calc_angular_acceleration(previousState);
            updatedState.angle_dot = previousState.angle_dot + (timeDelta * updatedState.angle_double_dot);
            updatedState.angle = previousState.angle + (timeDelta * updatedState.angle_dot);
            updatedState.F = previousState.F;
            updatedState.x_double_dot = calc_horizontal_acceleration(previousState);
            updatedState.x_dot = previousState.x_dot + (timeDelta * updatedState.x_double_dot);
            updatedState.x = previousState.x + (timeDelta * updatedState.x_dot);

            previousState.x = updatedState.x;
            previousState.angle = updatedState.angle;
            previousState.x_dot = updatedState.x_dot;
            previousState.angle_dot = updatedState.angle_dot;
            previousState.angle_double_dot = updatedState.angle_double_dot;
            previousState.x_double_dot = updatedState.x_double_dot;

            if ((stabilityCheckCounter % frameUpdateInterval) == 0) {
                cartComponent.setX(updatedState.x);
                rodComponent.setX(updatedState.x);
                rodComponent.setAngle(updatedState.angle);
                cartComponent.draw();
                rodComponent.draw();
            }

            bool beyondOperatingBounds = (previousState.x < (-2.4 + 0.3)) || (previousState.x > (2.4 - 0.3));
            bool poleCollapsed = (((previousState.angle * 180 / 3.14)) < -90) ||
                                (((previousState.angle * 180 / 3.14)) > 90);

            if (beyondOperatingBounds) {
                statusMessageText = "System exceeded operational boundaries.";
                std::cout << "FAILURE: " << statusMessageText << " at x = " << previousState.x << "m" << std::endl;
                std::cout << "  Angle at failure: " << (previousState.angle * 180.0 / 3.14) << "°" << std::endl;
                std::cout << "  Force applied: " << previousState.F << "N" << std::endl;
                std::cout << "  X velocity at failure: " << previousState.x_dot << "m/s" << std::endl;
                std::cout << "  Maximum position reached: " << maximumObservedPosition << "m" << std::endl;
                simulationComplete = true;
            } else if (poleCollapsed) {
                statusMessageText = "Pendulum has collapsed.";
                std::cout << "FAILURE: " << statusMessageText << " at angle = "
                         << (previousState.angle * 180 / 3.14) << "°" << std::endl;
                simulationComplete = true;
            } else {
                if ((stabilityCheckCounter % frameUpdateInterval) == 0) {
                    displayInfo(updatedState);
                }
            }

            if (totalOperationCycles > 80000) {
                statusMessageText = "Simulation timeout - system oscillating";
                std::cout << "WARNING: " << statusMessageText << std::endl;
                simulationComplete = true;
            }

            if (simulationComplete) {
                auto simulationEndTime = system_clock::now();
                duration<double> elapsedTime = simulationEndTime - simulationStartTime;
                std::string timeDisplay = to_string(elapsedTime.count()) + " sec.";

                if (systemStabilized) {
                    displayInfo(updatedState, "System stabilized", timeDisplay);
                    std::cout << "SUCCESS: System stabilized in " << timeDisplay << std::endl;
                    std::cout << "  Final angle: " << (updatedState.angle * 180.0 / 3.14) << "°" << std::endl;
                    std::cout << "  Final position: " << updatedState.x << "m" << std::endl;
                    std::cout << "  Maximum angle reached: " << maximumObservedAngle << "°" << std::endl;
                    std::cout << "  Maximum position reached: " << maximumObservedPosition << "m" << std::endl;
                } else {
                    displayInfo(updatedState, statusMessageText, timeDisplay);
                    std::cout << "FAILED after " << timeDisplay << std::endl;
                    std::cout << "  Maximum angle reached: " << maximumObservedAngle << "°" << std::endl;
                    std::cout << "  Maximum angular velocity: " << maximumObservedVelocity << " rad/s" << std::endl;
                    std::cout << "  Maximum position reached: " << maximumObservedPosition << "m" << std::endl;
                    std::cout << "  Total operation cycles: " << totalOperationCycles << std::endl;
                }
            }

            if ((stabilityCheckCounter % frameUpdateInterval) == 0) {
                setvisualpage(displayPageToggle);
#if defined __unix__ || defined __APPLE__
                refresh();
#endif
            }

            displayPageToggle = !displayPageToggle;

#if defined __WIN32__
            if (mousedown()) {
                // No action required
            }
#endif
        }

        if (!exitRequested) {
            std::cout << "\nPress Enter to test another angle, or type 'quit' to exit: ";
            std::string userResponse;
            getline(std::cin, userResponse);
            if (userResponse == "quit" || userResponse == "q" || userResponse == "exit") {
                exitRequested = true;
            }
        }
    }

    std::cout << "\nSimulation terminated." << std::endl;
    free_fuzzy_rules(&g_fuzzy_system);
}
void generateControlSurface_Angle_vs_Angle_Dot(){
    float inputs[2]; //Yamakawa

    cout << "Generating control surface (Angle vs. Angle_Dot)..." << endl;
    WorldStateType prevState, newState;
    srand(time(NULL));  // Seed the random number generator

    initPendulumWorld();

    float const h=0.002;

    prevState.init();
    newState.init();

    initFuzzySystem(&g_fuzzy_system);


    float angle_increment;
    float angle_dot_increment;

    float minAngle=0;
    float maxAngle=0;
    float angle=0.0;

    float angle_dot=0.0;
    float minAngleDot=0;
    float maxAngleDot=0;

    NUM_OF_DATA_POINTS=100;

//---------------------------------
    dataSet.x.resize(NUM_OF_DATA_POINTS);
    dataSet.y.resize(NUM_OF_DATA_POINTS);
    dataSet.z.resize(NUM_OF_DATA_POINTS);

    for(int y=0; y < NUM_OF_DATA_POINTS; y++){
       dataSet.z[y].resize(NUM_OF_DATA_POINTS);
    }
//---------------------------------
    minAngleDot= -3.0;
    maxAngleDot=  3.0;
    angle_dot_increment=(maxAngleDot-minAngleDot)/float(NUM_OF_DATA_POINTS);
    angle_dot=minAngleDot;
//---------------------------------
    minAngle=(-40.0)*3.14/180.0;
    maxAngle=(40.0)*3.14/180.0;
    angle_increment=(maxAngle-minAngle)/float(NUM_OF_DATA_POINTS);

//---------------------------------
    for(int row=0; row < NUM_OF_DATA_POINTS; row++){
         dataSet.y[row] = angle_dot;
         prevState.angle_dot = angle_dot;
         angle=minAngle;

         for(int col=0; col < NUM_OF_DATA_POINTS; col++){
             prevState.x=0.0;
             prevState.x_dot=0.0;
             prevState.x_double_dot = 0.0;
             prevState.angle = angle;
             prevState.angle_dot = angle_dot;
             prevState.angle_double_dot = 0.0;
             prevState.F = 0.0;


             dataSet.x[col] = angle;
             prevState.angle = angle;


             inputs[INPUT_X] = (coefficient_A * prevState.angle) + (coefficient_B * prevState.angle_dot);
             inputs[INPUT_Y] = (coefficient_C * prevState.x) + (coefficient_D * prevState.x_dot);

             prevState.F = 0.0;  //nothing is done.//fuzzy_system(inputs, g_fuzzy_system);


             //---------------------------------------------------------------------------
             //Calculate the new state of the world
             //Updating angle

             newState.angle_double_dot = calc_angular_acceleration(prevState);
             newState.angle_dot = prevState.angle_dot + (h * newState.angle_double_dot);
             newState.angle = prevState.angle + (h * newState.angle_dot);
             newState.F = prevState.F;

             //Updating x

             newState.x_double_dot = calc_horizontal_acceleration(prevState);
             newState.x_dot = prevState.x_dot + (h * newState.x_double_dot);
             newState.x = prevState.x + (h * newState.x_dot);

    //Update previous state
             prevState.x = newState.x;
             prevState.angle = newState.angle;
             prevState.x_dot = newState.x_dot;
             prevState.angle_dot = newState.angle_dot;
             prevState.angle_double_dot = newState.angle_double_dot;
             prevState.x_double_dot = newState.x_double_dot;

             //--------------------------
             inputs[INPUT_X] = (coefficient_A * prevState.angle) + (coefficient_B * prevState.angle_dot);
             inputs[INPUT_Y] = (coefficient_C * prevState.x) + (coefficient_D * prevState.x_dot);

             prevState.F = fuzzy_system(inputs, g_fuzzy_system);
             dataSet.z[row][col] = prevState.F; //record Force calculated

    //Set next case to examine; increment data points
          angle = angle + angle_increment;
      }
      angle_dot = angle_dot + angle_dot_increment;
   }

   free_fuzzy_rules(&g_fuzzy_system);
   cout << "done collecting data." << endl;
}


void saveDataToFile(string fileName){
	cout << "Saving control surface to file: " << fileName << "..." << endl;
	ofstream myfile;
	myfile.open (fileName, std::ofstream::out | std::ofstream::app);

	//Column Header
	for(int col=0; col < NUM_OF_DATA_POINTS; col++){
		if(col == 0){
		    myfile << "0.00, " << dataSet.x[col] << ",";
		} else if (col < (NUM_OF_DATA_POINTS-2)) {
			myfile << dataSet.x[col] << ",";
		} else {
			myfile << dataSet.x[col] << ",";
		}
	}
	myfile << endl;
	for(int row=0; row < NUM_OF_DATA_POINTS; row++){
	  for(int col=0; col < NUM_OF_DATA_POINTS; col++){
		  if(col == 0){
			  myfile << dataSet.y[row] << ", " << dataSet.z[row][col] << ","; //with Row header
		  }else if(col < (NUM_OF_DATA_POINTS-2)) {
           myfile << dataSet.z[row][col] << ",";
		  } else {
			  myfile << dataSet.z[row][col] << ",";
		  }
     }
	  myfile << endl;
   }

   myfile.close();
   cout << "Data set saved (File: " << fileName << ")" << endl;

}

void clearDataSet(){

	//Column Header
   for(int col=0; col < NUM_OF_DATA_POINTS; col++){
		dataSet.x[col] = 0.0;
   }

   for(int row=0; row < NUM_OF_DATA_POINTS; row++){
   	  dataSet.y[row] = 0.0;
	  for(int col=0; col < NUM_OF_DATA_POINTS; col++){
		  dataSet.z[row][col] = 0.0;
     }
   }
   cout << "DataSet cleared." << endl;

}


void init_sdlbgi (void)
{

#if defined __unix__ || defined __APPLE__

    // initialise SDL_bgi system
  setwinoptions ("",
  		 SDL_WINDOWPOS_CENTERED,
  		 SDL_WINDOWPOS_CENTERED,
  		 SDL_WINDOW_SHOWN);
  initwindow (800, 600);
  sdlbgifast ();


#endif

}

//---------------------------------------------------------------------------------//

int main(void) {

#if defined __unix__ || defined __APPLE__
   init_sdlbgi();

#elif defined __WIN32__

   int graphDriver = 0,graphMode = 0;
   initgraph(&graphDriver, &graphMode, "", 800, 600); // Start Window

#endif

   clearDataSet();
   try{
		runInvertedPendulum();

		//3) Enable this only after your fuzzy system has been completed already.
		generateControlSurface_Angle_vs_Angle_Dot();

		//4) Enable this only after your fuzzy system has been completed already.
		saveDataToFile("data_angle_vs_angle_dot.txt");

   }
   catch(...){
    	cout << "Exception caught!\n";
   }
	return 0;
}

