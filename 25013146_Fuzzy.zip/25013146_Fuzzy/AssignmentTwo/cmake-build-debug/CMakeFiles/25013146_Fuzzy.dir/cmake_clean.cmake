file(REMOVE_RECURSE
  "25013146_Fuzzy.exe"
  "25013146_Fuzzy.exe.manifest"
  "25013146_Fuzzy.pdb"
  "CMakeFiles/25013146_Fuzzy.dir/fuzzylogic.cpp.obj"
  "CMakeFiles/25013146_Fuzzy.dir/fuzzylogic.cpp.obj.d"
  "CMakeFiles/25013146_Fuzzy.dir/graphics.cpp.obj"
  "CMakeFiles/25013146_Fuzzy.dir/graphics.cpp.obj.d"
  "CMakeFiles/25013146_Fuzzy.dir/main.cpp.obj"
  "CMakeFiles/25013146_Fuzzy.dir/main.cpp.obj.d"
  "CMakeFiles/25013146_Fuzzy.dir/sprites.cpp.obj"
  "CMakeFiles/25013146_Fuzzy.dir/sprites.cpp.obj.d"
  "CMakeFiles/25013146_Fuzzy.dir/transform.cpp.obj"
  "CMakeFiles/25013146_Fuzzy.dir/transform.cpp.obj.d"
  "lib25013146_Fuzzy.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/25013146_Fuzzy.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
