
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "C:/Semester_(4)/25013146_Fuzzy/AssignmentTwo/fuzzylogic.cpp" "CMakeFiles/AssignmentTwo.dir/fuzzylogic.cpp.obj" "gcc" "CMakeFiles/AssignmentTwo.dir/fuzzylogic.cpp.obj.d"
  "C:/Semester_(4)/25013146_Fuzzy/AssignmentTwo/graphics.cpp" "CMakeFiles/AssignmentTwo.dir/graphics.cpp.obj" "gcc" "CMakeFiles/AssignmentTwo.dir/graphics.cpp.obj.d"
  "C:/Semester_(4)/25013146_Fuzzy/AssignmentTwo/main.cpp" "CMakeFiles/AssignmentTwo.dir/main.cpp.obj" "gcc" "CMakeFiles/AssignmentTwo.dir/main.cpp.obj.d"
  "C:/Semester_(4)/25013146_Fuzzy/AssignmentTwo/sprites.cpp" "CMakeFiles/AssignmentTwo.dir/sprites.cpp.obj" "gcc" "CMakeFiles/AssignmentTwo.dir/sprites.cpp.obj.d"
  "C:/Semester_(4)/25013146_Fuzzy/AssignmentTwo/transform.cpp" "CMakeFiles/AssignmentTwo.dir/transform.cpp.obj" "gcc" "CMakeFiles/AssignmentTwo.dir/transform.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
