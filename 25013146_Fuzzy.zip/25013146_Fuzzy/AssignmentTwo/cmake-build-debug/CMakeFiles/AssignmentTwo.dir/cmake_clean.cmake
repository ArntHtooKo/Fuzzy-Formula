file(REMOVE_RECURSE
  "AssignmentTwo.exe"
  "AssignmentTwo.exe.manifest"
  "AssignmentTwo.pdb"
  "CMakeFiles/AssignmentTwo.dir/fuzzylogic.cpp.obj"
  "CMakeFiles/AssignmentTwo.dir/fuzzylogic.cpp.obj.d"
  "CMakeFiles/AssignmentTwo.dir/graphics.cpp.obj"
  "CMakeFiles/AssignmentTwo.dir/graphics.cpp.obj.d"
  "CMakeFiles/AssignmentTwo.dir/main.cpp.obj"
  "CMakeFiles/AssignmentTwo.dir/main.cpp.obj.d"
  "CMakeFiles/AssignmentTwo.dir/sprites.cpp.obj"
  "CMakeFiles/AssignmentTwo.dir/sprites.cpp.obj.d"
  "CMakeFiles/AssignmentTwo.dir/transform.cpp.obj"
  "CMakeFiles/AssignmentTwo.dir/transform.cpp.obj.d"
  "libAssignmentTwo.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/AssignmentTwo.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
